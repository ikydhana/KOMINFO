package id.ac.poliban.jmp.aplikasimobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText editIsi;
    Button buttonShow, buttonTampil;
    TextView textTampil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    editIsi = findViewById(R.id.editIsi);
    buttonShow = findViewById(R.id.buttonShow);
    buttonTampil = findViewById(R.id.buttonTampil);
    textTampil = findViewById(R.id.textTampil);

    buttonShow.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Toast.makeText(MainActivity.this, "Nama : " + editIsi.getText(), Toast.LENGTH_SHORT).show();
        }
    });

    buttonTampil.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            textTampil.setText("Nama : " + editIsi.getText());
        }
    });

    }
}
